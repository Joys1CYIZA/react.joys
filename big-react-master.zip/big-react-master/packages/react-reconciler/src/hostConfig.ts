export * from 'react-dom/src/hostConfig';
