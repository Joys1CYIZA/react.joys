/**
 * 这个文件是为了方便demos下的示例调试用的
 */

export { createRoot } from './src/root';
