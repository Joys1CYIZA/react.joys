import * as ReactDOM from './src/root';

export default ReactDOM;
