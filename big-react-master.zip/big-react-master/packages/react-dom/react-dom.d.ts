declare let __LOG__: boolean;
